"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

interface SlideContent {
  title: string
  description: string
  image: string
}

const slides: SlideContent[] = [
  {
    title: "Gestión Gastronómica Simplificada",
    description: "VestaSys ofrece una interfaz intuitiva para gestionar todos los aspectos de su negocio gastronómico.",
    image: "/placeholder.svg?height=600&width=800",
  },
  {
    title: "Ideal para MIPYMEs y TCPs",
    description:
      "Diseñado específicamente para Micro, Pequeñas y Medianas Empresas y Trabajadores por Cuenta Propia del sector gastronómico.",
    image: "/placeholder.svg?height=600&width=800",
  },
  {
    title: "Solución Completa para Restaurantes",
    description:
      "Perfecto para bares, restaurantes, cafeterías, puestos de comida rápida y todo tipo de servicios gastronómicos.",
    image: "/placeholder.svg?height=600&width=800",
  },
]

const variants = {
  enter: (direction: number) => {
    return {
      x: direction > 0 ? 1000 : -1000,
      opacity: 0,
    }
  },
  center: {
    zIndex: 1,
    x: 0,
    opacity: 1,
  },
  exit: (direction: number) => {
    return {
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0,
    }
  },
}

const textVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      delay: 0.3,
      duration: 0.5,
    },
  },
}

export function ImageSlider() {
  const [[currentSlide, direction], setSlide] = useState([0, 0])

  const nextSlide = () => {
    setSlide((prev) => [prev[0] === slides.length - 1 ? 0 : prev[0] + 1, 1])
  }

  const prevSlide = () => {
    setSlide((prev) => [prev[0] === 0 ? slides.length - 1 : prev[0] - 1, -1])
  }

  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide()
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative h-full w-full overflow-hidden">
      <AnimatePresence initial={false} custom={direction}>
        <motion.div
          key={currentSlide}
          custom={direction}
          variants={variants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{
            x: { type: "spring", stiffness: 300, damping: 30 },
            opacity: { duration: 0.2 },
          }}
          className="absolute inset-0"
        >
          <img
            src={slides[currentSlide].image || "/placeholder.svg"}
            alt={slides[currentSlide].title}
            className="absolute inset-0 h-full w-full object-cover dark:brightness-[0.3]"
          />
          <motion.div
            className="relative z-10 flex h-full items-center justify-center"
            initial="hidden"
            animate="visible"
            variants={textVariants}
          >
            <div className="max-w-md p-6 text-center text-white">
              <motion.h2
                className="mb-2 text-3xl font-bold"
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4, duration: 0.5 }}
              >
                {slides[currentSlide].title}
              </motion.h2>
              <motion.p
                className="text-lg"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6, duration: 0.5 }}
              >
                {slides[currentSlide].description}
              </motion.p>
            </div>
          </motion.div>
        </motion.div>
      </AnimatePresence>

      <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
        {slides.map((_, index) => (
          <motion.button
            key={index}
            className={cn(
              "h-2 rounded-full transition-all",
              currentSlide === index ? "bg-white w-4" : "bg-white/50 w-2",
            )}
            onClick={() => setSlide([index, currentSlide > index ? -1 : 1])}
            whileHover={{ scale: 1.2 }}
            whileTap={{ scale: 0.9 }}
          />
        ))}
      </div>

      <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
        <Button
          variant="ghost"
          size="icon"
          className="absolute left-4 top-1/2 -translate-y-1/2 text-white hover:bg-black/20"
          onClick={prevSlide}
        >
          <ChevronLeft className="h-8 w-8" />
        </Button>
      </motion.div>

      <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
        <Button
          variant="ghost"
          size="icon"
          className="absolute right-4 top-1/2 -translate-y-1/2 text-white hover:bg-black/20"
          onClick={nextSlide}
        >
          <ChevronRight className="h-8 w-8" />
        </Button>
      </motion.div>
    </div>
  )
}
